#define GAME_NAME "Ants"
#define VERSION   "1.0"
